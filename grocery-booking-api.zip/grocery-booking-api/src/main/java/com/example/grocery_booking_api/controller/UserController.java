package com.example.grocery_booking_api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.grocery_booking_api.dto.BookGroceryItemDTO;
import com.example.grocery_booking_api.entity.GroceryItem;
import com.example.grocery_booking_api.repository.GroceryItemRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/user/groceries")
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class);
	private final GroceryItemRepository repository;

	public UserController(GroceryItemRepository repository) {
		this.repository = repository;
	}

	@GetMapping
	public ResponseEntity<List<GroceryItem>> viewAvailableGroceries() {
		logger.info("Fetching available groceries");
		return ResponseEntity.ok(repository.findAll());
	}

	@PostMapping("/book")
	public ResponseEntity<String> bookGroceries(@Valid @RequestBody List<BookGroceryItemDTO> items) {
		logger.info("Booking groceries for request: {}", items);

		for (BookGroceryItemDTO itemDTO : items) {
			GroceryItem existingItem = repository.findById(itemDTO.getId()).orElse(null);
			if (existingItem == null) {
				logger.warn("Item with ID {} not found", itemDTO.getId());
				return ResponseEntity.badRequest().body("Item not found: " + itemDTO.getId());
			}
			if (existingItem.getQuantity() < itemDTO.getQuantity()) {
				logger.warn("Insufficient inventory for item: {} (Requested: {}, Available: {})",
						existingItem.getName(), itemDTO.getQuantity(), existingItem.getQuantity());
				return ResponseEntity.badRequest().body("Insufficient inventory for item: " + existingItem.getName());
			}
			existingItem.setQuantity(existingItem.getQuantity() - itemDTO.getQuantity());
			repository.save(existingItem);
		}
		logger.info("Order placed successfully.");
		return ResponseEntity.ok("Order placed successfully.");
	}
}
