package com.example.grocery_booking_api.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

public class BookGroceryItemDTO {

	@NotNull(message = "Item ID is required.")
	private Long id;

	@NotNull(message = "Quantity is required.")
	@Min(value = 1, message = "Quantity must be at least 1.")
	private Integer quantity;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
}
