package com.example.grocery_booking_api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.grocery_booking_api.dto.GroceryItemDTO;
import com.example.grocery_booking_api.entity.GroceryItem;
import com.example.grocery_booking_api.exception.DuplicateItemException;
import com.example.grocery_booking_api.exception.InsufficientInventoryException;
import com.example.grocery_booking_api.exception.ItemNotFoundException;
import com.example.grocery_booking_api.repository.GroceryItemRepository;

@Service
public class GroceryItemService {

	@Autowired
	private GroceryItemRepository groceryItemRepository;

	// Add a new grocery item
	public GroceryItem addItem(GroceryItemDTO groceryItemDTO) {

		// Validation check for duplicate item
		if (groceryItemRepository.existsByName(groceryItemDTO.getName())) {
			throw new DuplicateItemException("Item already exists.");
		}

		GroceryItem groceryItem = new GroceryItem();
		groceryItem.setName(groceryItemDTO.getName());
		groceryItem.setPrice(groceryItemDTO.getPrice());
		groceryItem.setQuantity(groceryItemDTO.getQuantity());
		return groceryItemRepository.save(groceryItem);
	}

	// Get all grocery items
	public List<GroceryItem> getAllItems() {
		return groceryItemRepository.findAll();
	}

	// Get a specific grocery item by ID
	public GroceryItem getItemById(Long id) {
		return groceryItemRepository.findById(id)
				.orElseThrow(() -> new ItemNotFoundException("Item not found with ID: " + id));
	}

	// Update an existing grocery item
	public GroceryItem updateItem(Long id, GroceryItemDTO groceryItemDTO) {
		return groceryItemRepository.findById(id).map(existingItem -> {
			existingItem.setName(groceryItemDTO.getName());
			existingItem.setPrice(groceryItemDTO.getPrice());
			existingItem.setQuantity(groceryItemDTO.getQuantity());
			return groceryItemRepository.save(existingItem);
		}).orElseThrow(() -> new ItemNotFoundException("Item not found with ID: " + id));
	}

	// Delete a grocery item
	public boolean deleteItem(Long id) {
		if (!groceryItemRepository.existsById(id)) {
			throw new ItemNotFoundException("Item not found with ID: " + id);
		}
		groceryItemRepository.deleteById(id);
		return true;
	}

	// Update inventory for a grocery item
	public GroceryItem updateInventory(Long id, int quantity) {
		return groceryItemRepository.findById(id).map(existingItem -> {

			if (existingItem.getQuantity() < quantity) {
				throw new InsufficientInventoryException("Not enough stock to update inventory.");
			}

			existingItem.setQuantity(quantity);
			return groceryItemRepository.save(existingItem);
		}).orElseThrow(() -> new ItemNotFoundException("Item not found with ID: " + id));
	}
}
