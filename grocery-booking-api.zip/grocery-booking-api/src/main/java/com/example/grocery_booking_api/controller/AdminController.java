package com.example.grocery_booking_api.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.grocery_booking_api.dto.GroceryItemDTO;
import com.example.grocery_booking_api.entity.GroceryItem;
import com.example.grocery_booking_api.repository.GroceryItemRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/admin/groceries")

public class AdminController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);
	private final GroceryItemRepository repository;

	public AdminController(GroceryItemRepository repository) {
		this.repository = repository;
	}

	@PostMapping
	public ResponseEntity<GroceryItem> addGroceryItem(@Valid @RequestBody GroceryItemDTO itemDTO) {
		logger.info("Adding a new grocery item: {}", itemDTO.getName());
		GroceryItem item = new GroceryItem();
		item.setName(itemDTO.getName());
		item.setPrice(itemDTO.getPrice());
		item.setQuantity(itemDTO.getQuantity());
		return ResponseEntity.ok(repository.save(item));
	}

	@GetMapping
	public ResponseEntity<List<GroceryItem>> getAllGroceryItems() {
		logger.info("Fetching all grocery items");
		return ResponseEntity.ok(repository.findAll());
	}

	@PutMapping("/{id}")
	public ResponseEntity<GroceryItem> updateGroceryItem(@PathVariable Long id,
			@Valid @RequestBody GroceryItemDTO updatedItemDTO) {
		logger.info("Updating grocery item with ID: {}", id);
		return repository.findById(id).map(item -> {
			item.setName(updatedItemDTO.getName());
			item.setPrice(updatedItemDTO.getPrice());
			item.setQuantity(updatedItemDTO.getQuantity());
			return ResponseEntity.ok(repository.save(item));
		}).orElseGet(() -> {
			logger.warn("Grocery item with ID {} not found", id);
			return ResponseEntity.notFound().build();
		});
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteGroceryItem(@PathVariable Long id) {
		logger.info("Deleting grocery item with ID: {}", id);
		if (repository.existsById(id)) {
			repository.deleteById(id);
			return ResponseEntity.noContent().build();
		}
		logger.warn("Grocery item with ID {} not found", id);
		return ResponseEntity.notFound().build();
	}

	@PatchMapping("/{id}/inventory")
	public ResponseEntity<GroceryItem> updateInventory(@PathVariable Long id, @RequestParam Integer quantity) {
		logger.info("Updating inventory for grocery item with ID: {}, New Quantity: {}", id, quantity);
		return repository.findById(id).map(item -> {
			item.setQuantity(quantity);
			return ResponseEntity.ok(repository.save(item));
		}).orElseGet(() -> {
			logger.warn("Grocery item with ID {} not found", id);
			return ResponseEntity.notFound().build();
		});
	}
}
